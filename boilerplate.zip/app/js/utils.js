define(function(require, exports, module) {
	/*
	 * Função para carregamento dos módulos da aplicação
	 * Params: String nome do módulo, Function callback
	 * Retorno: callback
	 */
	var loadModule = function(modulo, callback) {
		if(modulo) {
			require([modulo.controller], function(mod) {
				if(callback) {
					callback(mod);
				}
			});
		}
	};

	/*
	 *	Função para validação de CPF
	 *	Params: String cpf
	 *	Retorno: true | false
	 */
	var validaCPF = function(cpf) {
		var Resto,
			Soma = 0;

		cpf = cpf.replace(/\D/gi, '');

		if(cpf === '' || cpf.length !== 11) {
			return false;
		}

		if(
			cpf === "00000000000" ||
			cpf === "11111111111" ||
			cpf === "22222222222" ||
			cpf === "33333333333" ||
			cpf === "44444444444" ||
			cpf === "55555555555" ||
			cpf === "66666666666" ||
			cpf === "77777777777" ||
			cpf === "88888888888" ||
			cpf === "99999999999"
			) {
			return false;
		}

		for(i=1; i<=9; i++) {
			Soma = Soma + parseInt(cpf.substring(i-1, i), 10) * (11 - i);
		}

		Resto = (Soma * 10) % 11;

		if((Resto === 10) || (Resto === 11)) {
			Resto = 0;
		}
		if(Resto !== parseInt(cpf.substring(9, 10), 10) ) {
			return false;
		}

		Soma = 0;

		for(i = 1; i <= 10; i++) {
			Soma = Soma + parseInt(cpf.substring(i-1, i), 10) * (12 - i);
		}

		Resto = (Soma * 10) % 11;

		if((Resto === 10) || (Resto === 11)) {
			Resto = 0;
		}

		if(Resto !== parseInt(cpf.substring(10, 11), 10) ) {
			return false;
		}

		return true;
	};

	/* Função para correção de strings deixando todas as palavras com a primeira letra maiúscula
	 * Params: String palavra(s)
	 * Retorno: String palavra(s) com a(s) primeira(s) letra(s) em maiúsculo
	 */
	var firstCharToUpper = function(str) {
		var arrStr = [],
			arrExclude = ['de', 'da', 'das', 'do', 'dos'],
			piece;

		_.each(str.split(' '), function(word) {
			word = word.toLowerCase();
			if(_.contains(arrExclude, word)) {
				arrStr.push(word);
			} else {
				piece = word.charAt(0).toUpperCase();
				arrStr.push(piece + word.substring(1));
			}
		});
		return arrStr.join(' ');
	};

	exports.loadModule = loadModule;
	exports.validaCPF = validaCPF;
	exports.firstCharToUpper = firstCharToUpper;
})