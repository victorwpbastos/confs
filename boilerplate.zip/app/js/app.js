define(function(require, exports, module){
	var Marionette = require('marionette'),
		Handlebars = require('handlebars'),
		Auth = require('modules/auth/controller'),
		Multimodal = require('multimodal')(this.marionetteApp);
		MenuView = require('views/menu'),
		AppHomeView = require('views/home'),
		Pagina404View = require('views/pagina404'),
		Utils = require('utils');

	// registra os templates
	require('../templates/templates');
	require('modules/inscricao/templates/templates');
	require('modules/auth/templates/templates');
	require('modules/admin/templates/templates');

	// registra os helpers do Handlebars
	require('handlebars_helpers');

	var App = new Marionette.Application();

	Marionette.Renderer.render = function(template, data){
		if (template) {
			template = Handlebars.templates[template];
			return template(data);
		}
	};

	App.addRegions({
		menu  : '#menu',
		main  : '#main'
	});

	exports.showView = function(region, view) {
		App.menu.show( new MenuView() );
		// inicia o módulo de autenticação e proteção das rotas da aplicação
		Auth.init(Utils);
		App[region].show(view);
	}

	exports.index = function() {
		this.showView('main', new AppHomeView());
	}

	exports.pagina404 = function() {
		App.menu.show( new MenuView() );
		this.showView('main', new Pagina404View());
	}

	exports.closeModal = function() {
		if(App.getRegion('modal')) {
			App.getRegion('modal').close();
		}
	}

	// jquery global timeout
	$.ajaxSetup({
		timeout: 30000
	});

	// jquery global error handler
	$(document).ajaxError(function(event, xhr, settings) {
		Multimodal.alert({
			title: '<span class="text-danger">Mensagem</span>',
			message: 'Erro de comunicação com o servidor! Favor executar a operação novamente.'
		});
	});

	exports.marionetteApp = App;
});