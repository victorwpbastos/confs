var devMode = true;

require.config({
	waitSeconds: 0,
	urlArgs: 'v=0.0.1',
	baseUrl: 'app/js/libs',

	paths: {
		'handlebars': devMode ? 'handlebars' : 'handlebars.runtime'
	},

	shim: {
		'underscore': {
			deps: ['jquery'],
			exports: '_'
		},
		'backbone': {
			deps: ['underscore'],
			exports: 'Backbone'
		},
		'marionette': {
			deps: ['backbone'],
			exports: 'Marionette'
		},
		'handlebars': {
			deps: ['jquery'],
			exports: 'Handlebars'
		}
	}
});

require(['jquery', 'handlebars'], function($) {
	console.log(Handlebars);
	// console.log(Marionette);
	// console.log(Handlebars);
});